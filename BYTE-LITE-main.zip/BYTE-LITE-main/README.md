
## <p align="center"> BYTE-V.lite WHATSAPP BOT
<br>
<strong>Looking for the BYTE-MD? then</strong>
<a href="https://github.com/HyHamza/BYTE-MD">Click Here</a>


<img src="https://raw.githubusercontent.com/HyHamza/HyHamza/main/Images/BYTE-MD-LITE.jpeg" width="540" height="auto" />
</p>     

### Setup

**DEPLOY ON HEROKU**
   - **Click [`FORK`](https://github.com/HyHamza/BYTE-MD-LITE/fork) and `Star ⭐ Repository` for Courage.**
   - You will get a session ID in WhatsApp, copy the ID only.
   - **If you don't have an account on [Heroku](https://signup.heroku.com/), [create an account now](https://signup.heroku.com/).**
</p>
🌟 Hamza's Portfolio 🌟

<a href="https://HyHamza.vercel.app/">Click Here</a>

**Linking methods**

##  Pairing link:1

<a href="https://byte-session.vercel.app/"><img src="https://img.shields.io/badge/LOGIN%20WITH-PAIR%20CODE-red" alt="LOGIN WITH PAIR CODE" width="250"></a>

## Pairing link:2 (if above isn't working)

<a href="https://byte-session-2.vercel.app/"><img src="https://img.shields.io/badge/LOGIN%20WITH-PAIR%20CODE2-red" alt="LOGIN WITH PAIR CODE" width="250"></a>
## DEPLOY IN HEROKU

 [![Deploy on Heroku](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/HyHamza/BYTE-MD-LITE/)

   </details>
</P>





## Contributions

Contributions to BYTE-MD-LITE are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request.

## License

The BYTE-MD-LITE is released.

Enjoy the diverse features of the BYTE-MD-LITE  to enhance your conversations and make your WhatsApp experience more interesting!

## Developer:
- [**Hamza**](https://wa.me/923072380380)

**Thanks to:**
## Allah

